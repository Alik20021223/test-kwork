import { useEffect } from "react";
import TeamBlock from "../../components/team-block/component";
import { mockDataTeam } from "./mock";
import AOS from "aos";
import "aos/dist/aos.css";

const TeamSection = () => {
  useEffect(() => {
    AOS.init({
      disable: "phone",
      duration: 700,
      easing: "ease-out-cubic",
    });
  }, []);

  return (
    <>
      <div data-aos="fade-up">
        <section className="bg-[#eeecec] rounded-3xl space-y-16 py-12">
          <h1 className="text-black">Команда \\\ Dream team</h1>

          <div className="flex justify-around items-center">
            {mockDataTeam.map((item) => (
              <TeamBlock props={item} key={item.id} />
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default TeamSection;
