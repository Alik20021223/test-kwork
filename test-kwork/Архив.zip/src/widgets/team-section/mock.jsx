export const mockDataTeam = [
  {
    id: 1,
    img: "./public/image.png",
    name: "stamp_qw",
    job: "founder full-stack developer",
    describe:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. In, explicabo.",
  },
  {
    id: 2,
    img: "./public/gladiator.png",
    name: "gladiator",
    job: "founder back-end devops",
    describe:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. In, explicabo.",
  },
  {
    id: 3,
    img: "./public/me.jpg",
    name: "alik1223",
    job: "frontend developer",
    describe:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. In, explicabo.",
  },
];
