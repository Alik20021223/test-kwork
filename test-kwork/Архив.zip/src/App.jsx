import "./App.css";
import TeamSection from "./widgets/team-section/content";

function App() {
  return (
    <>
      <TeamSection />
    </>
  );
}

export default App;
