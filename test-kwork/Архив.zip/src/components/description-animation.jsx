import React from "react";

const DescriptionAnim = () => {
  return (
    <div id="two">
      <p>I speak</p>
      <div className="box">
        <ul>
          <li className="item-1">English</li>
          <li className="item-2">Maltese</li>
          <li className="item-3">Danish</li>
          <li className="item-4">Italian</li>
          <li className="item-5">English</li>
        </ul>
      </div>
    </div>
  );
};

export default DescriptionAnim;
